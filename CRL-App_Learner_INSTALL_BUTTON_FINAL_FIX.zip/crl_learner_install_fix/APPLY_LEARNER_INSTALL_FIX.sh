#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"
cd "$ROOT"

mkdir -p app/learner/download/manifest.webmanifest public

cp -f "$(dirname "$0")/app/learner/download/page.jsx" app/learner/download/page.jsx
cp -f "$(dirname "$0")/app/learner/download/layout.jsx" app/learner/download/layout.jsx
cp -f "$(dirname "$0")/app/learner/download/manifest.webmanifest/route.js" app/learner/download/manifest.webmanifest/route.js
cp -f "$(dirname "$0")/public/learner-pwa-sw.js" public/learner-pwa-sw.js

# The old competing learner manifest/route is deliberately removed.
rm -rf app/learner/manifest.webmanifest
rm -rf app/learner/app

printf '\nCRL-App Learner install fix applied.\n'
printf 'Download page: /learner/download\n'
printf 'Installed app: CRL-App Learner\n'
printf 'Installed start URL: /learner\n'
printf 'Installed scope: /learner/\n'
printf '\nThe existing app/learner/page.jsx is intentionally preserved.\n'
